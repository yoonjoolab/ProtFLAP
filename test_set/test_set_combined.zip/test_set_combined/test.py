import os
import sys
import torch
from torch_geometric.data import DataLoader, Batch

# =========================================================
# Paths
# test.py is INSIDE test_set_combined
# =========================================================
THIS_DIR = os.path.abspath(os.path.dirname(__file__))

# ProtFLAP root is two levels up
PROTFLAP_ROOT = os.path.abspath(os.path.join(THIS_DIR, "../.."))

# Make bin/ importable
sys.path.insert(0, PROTFLAP_ROOT)

# =========================================================
# Imports
# =========================================================
from bin.train_val import build_dataset_from_folder
from bin.gnn_model import NodeMLP_GCN
from bin.evaluate import (
    compute_metrics,
    evaluate_and_plot_confusion_matrix_per_residue
)
from bin.data_utils import load_rmsf_data

# =========================================================
# Device
# =========================================================
device = "cuda" if torch.cuda.is_available() else "cpu"

# =========================================================
# Best hyperparameters
# =========================================================
default_params = {
    "learning_rate": 0.0001,
    "dropout": 0.06837534221738543,
    "weight_decay": 0.0001,
    "batch_norm": False,
    "residual": True,
    "activation": "ReLU",
    "use_bias": True,
    "hidden_dim": 128,
    "num_gcn_layers": 4
}

# =========================================================
# Test function
# =========================================================
def test_with_defaults(hyperparams=default_params):

    # EXACTLY like your old code: read from current folder
    test_data_dir = THIS_DIR
    print("Reading test data from:", test_data_dir)

    dataset = build_dataset_from_folder(test_data_dir)
    print(f"Loaded {len(dataset)} protein graphs for testing.")

    if len(dataset) == 0:
        raise RuntimeError(
            "Dataset is empty. CSV/PDB names must match exactly "
            "(e.g., 3b1fA02_min.pdb + 3b1fA02_min.csv)."
        )

    in_node_feats = dataset[0].x.size(1)

    model = NodeMLP_GCN(
        in_node_feats,
        hidden_dim=hyperparams["hidden_dim"],
        num_gcn_layers=hyperparams["num_gcn_layers"],
        dropout=hyperparams["dropout"],
        use_residual=hyperparams["residual"],
        use_batch_norm=hyperparams["batch_norm"],
        activation=hyperparams["activation"],
        use_bias=hyperparams["use_bias"],
    ).to(device)

    # =====================================================
    # Load trained model
    # =====================================================
    model_path = os.path.join(PROTFLAP_ROOT, "models", "best_model_cv.pth")
    model.load_state_dict(torch.load(model_path, map_location=device))
    model.eval()

    loader = DataLoader(
        dataset,
        batch_size=16,
        shuffle=False,
        collate_fn=Batch.from_data_list
    )

    # =====================================================
    # Evaluation
    # =====================================================
    cm, labels, preds, sigmoids, logits, rmsf = (
        evaluate_and_plot_confusion_matrix_per_residue(
            model,
            loader,
            fold_id="test",
            device=device,
            load_rmsf_fn=load_rmsf_data
        )
    )

    acc, f1, mcc, precision, recall, fpr, tpr, roc_auc = compute_metrics(
        labels, preds, sigmoids
    )

    print(
        f"Accuracy: {acc:.4f}, "
        f"F1: {f1:.4f}, "
        f"MCC: {mcc:.4f}, "
        f"Precision: {precision:.4f}, "
        f"Recall: {recall:.4f}, "
        f"AUC: {roc_auc:.4f}"
    )

    # =====================================================
    # Save ROC curve
    # =====================================================
    import matplotlib.pyplot as plt

    plt.figure()
    plt.plot(fpr, tpr, label=f"AUC = {roc_auc:.4f}")
    plt.plot([0, 1], [0, 1], "k--", label="Random")
    plt.xlabel("False Positive Rate")
    plt.ylabel("True Positive Rate")
    plt.legend(frameon=False)
    plt.tight_layout()
    plt.savefig("test_roc_curve.png", dpi=300)
    plt.close()

    # =====================================================
    # Save metrics
    # =====================================================
    with open("test_results.txt", "w") as f:
        f.write(f"Confusion Matrix:\n{cm}\n\n")
        f.write(f"Accuracy: {acc:.4f}\n")
        f.write(f"F1 Score: {f1:.4f}\n")
        f.write(f"MCC: {mcc:.4f}\n")
        f.write(f"Precision: {precision:.4f}\n")
        f.write(f"Recall: {recall:.4f}\n")
        f.write(f"ROC AUC: {roc_auc:.4f}\n")

# =========================================================
# Run
# =========================================================
if __name__ == "__main__":
    test_with_defaults()

