import os
import torch
from torch_geometric.data import DataLoader, Batch
from train_val import build_dataset_from_folder
from gnn_model import NodeMLP_GCN, FocalLoss
from evaluate import compute_metrics, evaluate_and_plot_confusion_matrix_per_residue

from data_utils import load_rmsf_data
from prediction_utils import get_predictions, compare_rmsf_and_predictions

device = "cuda" if torch.cuda.is_available() else "cpu"

# Updated default hyperparameters (Best Trial)
default_params = {
    "learning_rate": 0.001,
    "dropout": 0.1733765406650172,   # updated
    "weight_decay": 0.0001,
    "batch_norm": True,
    "residual": True,
    "activation": "ReLU",
    "use_bias": False,                # updated
    "hidden_dim": 64,
    "num_gcn_layers": 3               # updated

}

def test_with_defaults(hyperparams=None):
    if hyperparams is None:
        hyperparams = default_params
    folder = os.getcwd()
    dataset = build_dataset_from_folder(folder)
    print(f"Loaded {len(dataset)} protein graphs for testing.")

    in_node_feats = dataset[0].x.size(1)
    model = NodeMLP_GCN(
        in_node_feats,
        hidden_dim=hyperparams["hidden_dim"],
        num_gcn_layers=hyperparams["num_gcn_layers"],
        dropout=hyperparams["dropout"],
        use_residual=hyperparams["residual"],
        use_batch_norm=hyperparams["batch_norm"],
        activation=hyperparams["activation"],
        use_bias=False,
    ).to(device)

    # Load the trained weights
    model.load_state_dict(torch.load("best_model_cv.pth", map_location=device))

    loader = DataLoader(dataset, batch_size=16, shuffle=False, collate_fn=Batch.from_data_list)

    cm, labels, preds, sigmoids, logits, rmsf = evaluate_and_plot_confusion_matrix_per_residue(
    model,
    loader,
    fold_id="test",
    device=device,
    load_rmsf_fn=load_rmsf_data
    )


    acc, f1, mcc, precision, recall, fpr, tpr, roc_auc = compute_metrics(labels, preds, sigmoids)

    print(f"Accuracy: {acc:.4f}, F1: {f1:.4f}, MCC: {mcc:.4f}, Precision: {precision:.4f}, Recall: {recall:.4f}, AUC: {roc_auc:.4f}")

    # Save ROC curve plot
    import matplotlib.pyplot as plt
    plt.figure()
    plt.plot(fpr, tpr, label=f"AUC: {roc_auc:.4f}")
    plt.plot([0, 1], [0, 1], "k--", label="Random")
    plt.xlabel("False Positive Rate")
    plt.ylabel("True Positive Rate")
    plt.title("ROC Curve on Test Set")
    plt.legend()
    plt.savefig("test_roc_curve.png")
    plt.close()

    # Save metrics into a text file
    with open("test_results.txt", "w") as f:
        f.write(f"Confusion Matrix:\n{cm}\n\n")
        f.write(f"Accuracy: {acc:.4f}\nF1 Score: {f1:.4f}\nMatthews Corrcoef: {mcc:.4f}\n")
        f.write(f"Precision: {precision:.4f}\nRecall: {recall:.4f}\nROC AUC: {roc_auc:.4f}\n")

if __name__ == "__main__":
    test_with_defaults()

